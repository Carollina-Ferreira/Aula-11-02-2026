export function App() {

  return (
    <>
      <main>
        <h1>Bem-vindo</h1>

        <p>Digite suas credenciais para acessar o sistema</p>
        <input type="email" placeholder="Email" />
        <input type="password" placeholder="Senha" />

        <button>Entrar</button>
      </main>
    </>
  )
}

